{pkgs}: {
  deps = [
    pkgs.tree
  ];
}
